/**
 * All the function related to Bulk Smushing page
 *
 * @author Umesh Kumar <umeshsingla05@gmail.com>
 *
 * @since 2.7.1
 *
 */